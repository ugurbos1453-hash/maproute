package com.example.maproute

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Dokunulmayan, sadece isaret cizen seffaf katman (hata ayiklama). */
class MarkerView(ctx: Context) : View(ctx) {
    private class M(val x: Float, val y: Float, val color: Int, val until: Long)
    private val items = mutableListOf<M>()
    private val loc = IntArray(2)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f }

    fun add(x: Int, y: Int, color: Int, durMs: Long) {
        items.add(M(x.toFloat(), y.toFloat(), color, System.currentTimeMillis() + durMs))
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        getLocationOnScreen(loc)
        val now = System.currentTimeMillis()
        items.removeAll { it.until < now }
        for (m in items) {
            p.color = m.color
            val cx = m.x - loc[0]
            val cy = m.y - loc[1]
            c.drawCircle(cx, cy, 34f, p)
            c.drawLine(cx - 44f, cy, cx + 44f, cy, p)
            c.drawLine(cx, cy - 44f, cx, cy + 44f, p)
        }
        if (items.isNotEmpty()) postInvalidateDelayed(100)
    }
}
