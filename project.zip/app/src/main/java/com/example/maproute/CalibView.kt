package com.example.maproute

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Point
import android.graphics.Rect
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** 0 = portal alani, 1 = atlama tusu, 2 = rota dairesi, 3 = harita tusu, 5 = sari portal alani, 6 = uyari alani */
class CalibView(
    ctx: Context,
    private val cfg: Cfg,
    private val mode: Int,
    private val done: () -> Unit
) : FrameLayout(ctx) {

    private var zone: Rect? = cfg.rect(when (mode) { 5 -> "yzone"; 6 -> "azone"; else -> "zone" })
    private var jump: Point? = cfg.point("jump")
    private var mapBtn: Point? = cfg.point("mapbtn")
    private val circ: FloatArray = cfg.circle() ?: run {
        val dm = resources.displayMetrics
        floatArrayOf(dm.widthPixels / 2f, dm.heightPixels / 2f, minOf(dm.widthPixels, dm.heightPixels) * 0.2f)
    }
    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var dragging = false
    private var lx = 0f
    private var ly = 0f
    private var multi = false
    private var d0 = 0f
    private var r0 = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 5f; textSize = 36f }
    private val loc = IntArray(2)

    init {
        setBackgroundColor(0x33000000)
        setWillNotDraw(false)
        val msg = when (mode) {
            0 -> "Mavi portalın çıkacağı alanı parmağınla sürükleyerek çiz (halkanın etrafında biraz boşluk bırak)"
            1 -> "Atlama butonunun olduğu yere bir kez dokun (harita kapalı olmalı)"
            3 -> "Haritayı açıp kapatan butona (sağ üst) bir kez dokun"
            6 -> "UYARI alanı: dolu mavi dairenin aranacağı alanı sürükleyerek çiz (haritanın tamamı olabilir)"
            5 -> "SARI portalın çıkacağı alanı sürükleyerek çiz (halkanın etrafında boşluk bırak)"
            else -> "Rota dairesi: tek parmakla sürükle = taşı, iki parmakla aç/kapa = büyüt/küçült. Kırmızı nokta başlangıç noktası"
        }
        addView(TextView(ctx).apply {
            text = msg
            setTextColor(Color.WHITE)
            setBackgroundColor(0xCC000000.toInt())
            setPadding(24, 16, 24, 16)
            textSize = 14f
        }, LayoutParams(WC, WC, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        val bar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, a: () -> Unit) {
            bar.addView(Button(ctx).apply { text = t; isAllCaps = false; setOnClickListener { a() } })
        }
        btn("Kaydet") { save() }
        if (mode == 2) {
            btn("Büyüt") { circ[2] = (circ[2] * 1.1f).coerceAtMost(3000f); invalidate() }
            btn("Küçült") { circ[2] = (circ[2] * 0.9f).coerceAtLeast(30f); invalidate() }
        }
        btn("İptal") { done() }
        addView(bar, LayoutParams(WC, WC, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
    }

    private fun save() {
        when (mode) {
            0 -> { val z = zone ?: return; cfg.putRect("zone", z) }
            5 -> { val z = zone ?: return; cfg.putRect("yzone", z) }
            6 -> { val z = zone ?: return; cfg.putRect("azone", z) }
            1 -> { val j = jump ?: return; cfg.putPoint("jump", j) }
            3 -> { val m = mapBtn ?: return; cfg.putPoint("mapbtn", m) }
            else -> cfg.putCircle(circ[0], circ[1], circ[2])
        }
        done()
    }

    private fun px(e: MotionEvent, i: Int): Float = e.getX(i) + loc[0]
    private fun py(e: MotionEvent, i: Int): Float = e.getY(i) + loc[1]
    private fun dist(e: MotionEvent): Float {
        val dx = (px(e, 0) - px(e, 1)).toDouble()
        val dy = (py(e, 0) - py(e, 1)).toDouble()
        return kotlin.math.hypot(dx, dy).toFloat()
    }

    private fun circleTouch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { multi = false; lx = px(e, 0); ly = py(e, 0) }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount >= 2) { multi = true; d0 = dist(e); r0 = circ[2] }
            }
            MotionEvent.ACTION_MOVE -> {
                if (multi) {
                    if (e.pointerCount >= 2 && d0 > 10f) circ[2] = (r0 * dist(e) / d0).coerceIn(30f, 3000f)
                } else {
                    val x = px(e, 0)
                    val y = py(e, 0)
                    circ[0] += x - lx
                    circ[1] += y - ly
                    lx = x
                    ly = y
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { multi = false }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        getLocationOnScreen(loc)
        when (mode) {
            0, 5, 6 -> {
                val x = e.rawX
                val y = e.rawY
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = x; sy = y; ex = x; ey = y; dragging = true }
                    MotionEvent.ACTION_MOVE -> { ex = x; ey = y }
                    MotionEvent.ACTION_UP -> {
                        ex = x; ey = y; dragging = false
                        zone = Rect(minOf(sx, ex).toInt(), minOf(sy, ey).toInt(), maxOf(sx, ex).toInt(), maxOf(sy, ey).toInt())
                    }
                }
            }
            1 -> if (e.action == MotionEvent.ACTION_UP) { jump = Point(e.rawX.toInt(), e.rawY.toInt()) }
            3 -> if (e.action == MotionEvent.ACTION_UP) { mapBtn = Point(e.rawX.toInt(), e.rawY.toInt()) }
            else -> circleTouch(e)
        }
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        p.style = Paint.Style.STROKE
        p.color = Color.YELLOW
        if (mode == 0 || mode == 5 || mode == 6) {
            if (dragging) {
                c.drawRect(minOf(sx, ex) - ox, minOf(sy, ey) - oy, maxOf(sx, ex) - ox, maxOf(sy, ey) - oy, p)
            } else {
                zone?.let { c.drawRect(it.left - ox, it.top - oy, it.right - ox, it.bottom - oy, p) }
            }
        }
        p.color = Color.RED
        jump?.let { c.drawCircle(it.x - ox, it.y - oy, 30f, p) }
        p.color = Color.MAGENTA
        mapBtn?.let { c.drawCircle(it.x - ox, it.y - oy, 30f, p) }
        if (mode == 2) {
            val cx = circ[0] - ox
            val cy = circ[1] - oy
            p.color = Color.GREEN
            p.strokeWidth = 6f
            c.drawCircle(cx, cy, circ[2], p)
            c.drawLine(cx - 20f, cy, cx + 20f, cy, p)
            c.drawLine(cx, cy - 20f, cx, cy + 20f, p)
            p.style = Paint.Style.FILL
            p.color = Color.RED
            c.drawCircle(cx, cy - circ[2], 12f, p)
            p.color = Color.WHITE
            c.drawText("r = ${circ[2].toInt()} px", cx + 14f, cy + 44f, p)
            p.strokeWidth = 5f
        }
    }
}
