package com.example.maproute

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Point
import android.graphics.Rect
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** mode 0 = portal bolgesi, 1 = atlama butonu, 2 = rota */
class CalibView(
    ctx: Context,
    private val cfg: Cfg,
    private val mode: Int,
    private val done: () -> Unit
) : FrameLayout(ctx) {

    private var zone: Rect? = cfg.rect("zone")
    private var jump: Point? = cfg.point("jump")
    private val route = cfg.waypoints().toMutableList()
    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var dragging = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 5f; textSize = 38f }
    private val loc = IntArray(2)

    init {
        setBackgroundColor(0x33000000)
        setWillNotDraw(false)
        val msg = when (mode) {
            0 -> "Portalin cikacagi alani parmagini surukleyerek ciz (halkanin etrafinda biraz bosluk birak)"
            1 -> "Atlama butonunun oldugu yere bir kez dokun"
            else -> "Rota noktalarina sirayla dokun (haritada). Numaralar gorunur"
        }
        addView(TextView(ctx).apply {
            text = msg
            setTextColor(Color.WHITE)
            setBackgroundColor(0xCC000000.toInt())
            setPadding(24, 16, 24, 16)
            textSize = 14f
        }, LayoutParams(WC, WC, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        val bar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, a: () -> Unit) {
            bar.addView(Button(ctx).apply { text = t; isAllCaps = false; setOnClickListener { a() } })
        }
        btn("Kaydet") { save() }
        if (mode == 2) {
            btn("Geri al") { if (route.isNotEmpty()) route.removeAt(route.size - 1); invalidate() }
        }
        btn("Iptal") { done() }
        addView(bar, LayoutParams(WC, WC, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
    }

    private fun save() {
        when (mode) {
            0 -> { val z = zone ?: return; cfg.putRect("zone", z) }
            1 -> { val j = jump ?: return; cfg.putPoint("jump", j) }
            else -> { if (route.isEmpty()) return; cfg.putWaypoints(route) }
        }
        done()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.rawX
        val y = e.rawY
        when (mode) {
            0 -> when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = x; sy = y; ex = x; ey = y; dragging = true }
                MotionEvent.ACTION_MOVE -> { ex = x; ey = y }
                MotionEvent.ACTION_UP -> {
                    ex = x; ey = y; dragging = false
                    zone = Rect(minOf(sx, ex).toInt(), minOf(sy, ey).toInt(), maxOf(sx, ex).toInt(), maxOf(sy, ey).toInt())
                }
            }
            1 -> if (e.action == MotionEvent.ACTION_UP) { jump = Point(x.toInt(), y.toInt()) }
            else -> if (e.action == MotionEvent.ACTION_UP) { route.add(Point(x.toInt(), y.toInt())) }
        }
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        p.style = Paint.Style.STROKE
        p.color = Color.YELLOW
        if (dragging) {
            c.drawRect(minOf(sx, ex) - ox, minOf(sy, ey) - oy, maxOf(sx, ex) - ox, maxOf(sy, ey) - oy, p)
        } else {
            zone?.let { c.drawRect(it.left - ox, it.top - oy, it.right - ox, it.bottom - oy, p) }
        }
        p.color = Color.RED
        jump?.let { c.drawCircle(it.x - ox, it.y - oy, 30f, p) }
        p.color = Color.GREEN
        for ((i, pt) in route.withIndex()) {
            p.style = Paint.Style.STROKE
            c.drawCircle(pt.x - ox, pt.y - oy, 16f, p)
            p.style = Paint.Style.FILL
            c.drawText("${i + 1}", pt.x - ox + 20, pt.y - oy - 20, p)
        }
    }
}
