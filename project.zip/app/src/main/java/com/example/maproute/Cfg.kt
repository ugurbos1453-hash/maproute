package com.example.maproute

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Point
import android.graphics.Rect

const val WC = -2
const val MP = -1

class Cfg(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun f(k: String, d: Float): Float = sp.getFloat(k, d)
    fun put(k: String, v: Float) { sp.edit().putFloat(k, v).apply() }

    fun rect(k: String): Rect? {
        val s = sp.getString(k, null) ?: return null
        val p = s.split(",").mapNotNull { it.toIntOrNull() }
        return if (p.size == 4) Rect(p[0], p[1], p[2], p[3]) else null
    }
    fun putRect(k: String, r: Rect) {
        sp.edit().putString(k, "${r.left},${r.top},${r.right},${r.bottom}").apply()
    }

    fun point(k: String): Point? {
        val s = sp.getString(k, null) ?: return null
        val p = s.split(",").mapNotNull { it.toIntOrNull() }
        return if (p.size == 2) Point(p[0], p[1]) else null
    }
    fun putPoint(k: String, p: Point) {
        sp.edit().putString(k, "${p.x},${p.y}").apply()
    }

    fun waypoints(): List<Point> {
        val s = sp.getString("route", "") ?: ""
        return s.split(";").mapNotNull { q ->
            val a = q.split(",").mapNotNull { it.toIntOrNull() }
            if (a.size == 2) Point(a[0], a[1]) else null
        }
    }
    fun putWaypoints(l: List<Point>) {
        sp.edit().putString("route", l.joinToString(";") { "${it.x},${it.y}" }).apply()
    }
}

data class Hit(val n: Int, val x: Int, val y: Int)

object Detector {
    /** Bolge icinde cyan/mavi pikselleri sayar, agirlik merkezini dondurur. */
    fun scan(bmp: Bitmap, zone: Rect, c: Cfg): Hit {
        val l = zone.left.coerceIn(0, bmp.width - 2)
        val t = zone.top.coerceIn(0, bmp.height - 2)
        val r = zone.right.coerceIn(l + 1, bmp.width)
        val b = zone.bottom.coerceIn(t + 1, bmp.height)
        val w = r - l
        val h = b - t
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, l, t, w, h)
        val hMin = c.f("hMin", 180f)
        val hMax = c.f("hMax", 220f)
        val sMin = c.f("sMin", 0.45f)
        val vMin = c.f("vMin", 0.5f)
        val hsv = FloatArray(3)
        var n = 0
        var sx = 0L
        var sy = 0L
        for (y in 0 until h) {
            for (x in 0 until w) {
                Color.colorToHSV(px[y * w + x], hsv)
                if (hsv[0] >= hMin && hsv[0] <= hMax && hsv[1] >= sMin && hsv[2] >= vMin) {
                    n++; sx += x; sy += y
                }
            }
        }
        return if (n > 0) Hit(n, l + (sx / n).toInt(), t + (sy / n).toInt()) else Hit(0, 0, 0)
    }

    fun find(bmp: Bitmap, zone: Rect, c: Cfg): Hit? {
        val h = scan(bmp, zone, c)
        return if (h.n >= c.f("minPx", 40f).toInt()) h else null
    }
}
