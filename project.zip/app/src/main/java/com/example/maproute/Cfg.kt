package com.example.maproute

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Point
import android.graphics.Rect

const val WC = -2
const val MP = -1

class Cfg(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun f(k: String, d: Float): Float = sp.getFloat(k, d)
    fun put(k: String, v: Float) { sp.edit().putFloat(k, v).apply() }

    fun rect(k: String): Rect? {
        val s = sp.getString(k, null) ?: return null
        val p = s.split(",").mapNotNull { it.toIntOrNull() }
        return if (p.size == 4) Rect(p[0], p[1], p[2], p[3]) else null
    }
    fun putRect(k: String, r: Rect) {
        sp.edit().putString(k, "${r.left},${r.top},${r.right},${r.bottom}").apply()
    }

    fun point(k: String): Point? {
        val s = sp.getString(k, null) ?: return null
        val p = s.split(",").mapNotNull { it.toIntOrNull() }
        return if (p.size == 2) Point(p[0], p[1]) else null
    }
    fun putPoint(k: String, p: Point) {
        sp.edit().putString(k, "${p.x},${p.y}").apply()
    }

    fun waypoints(): List<Point> {
        val s = sp.getString("route", "") ?: ""
        return s.split(";").mapNotNull { q ->
            val a = q.split(",").mapNotNull { it.toIntOrNull() }
            if (a.size == 2) Point(a[0], a[1]) else null
        }
    }
    fun putWaypoints(l: List<Point>) {
        sp.edit().putString("route", l.joinToString(";") { "${it.x},${it.y}" }).apply()
    }
}

data class Hit(val n: Int, val x: Int, val y: Int, val raw: Int = 0)

object Detector {
    /**
     * Bolgedeki cyan/mavi pikselleri bulur, bagli parcalara ayirir.
     * Sadece halka benzeri (kareye yakin, ici bos) parcalar portal sayilir.
     * Dolu noktalar (gemi isareti vb.) ve ince/uzun cizgiler elenir.
     */
    fun scan(bmp: Bitmap, zone: Rect, c: Cfg): Hit {
        val l = zone.left.coerceIn(0, bmp.width - 2)
        val t = zone.top.coerceIn(0, bmp.height - 2)
        val r = zone.right.coerceIn(l + 1, bmp.width)
        val b = zone.bottom.coerceIn(t + 1, bmp.height)
        val w = r - l
        val h = b - t
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, l, t, w, h)
        val hMin = c.f("hMin", 180f)
        val hMax = c.f("hMax", 220f)
        val sMin = c.f("sMin", 0.45f)
        val vMin = c.f("vMin", 0.5f)
        val maxFill = c.f("maxFill", 0.6f)

        val cs = 3
        val cw = (w + cs - 1) / cs
        val ch = (h + cs - 1) / cs
        val cellN = IntArray(cw * ch)
        val hsv = FloatArray(3)
        var raw = 0
        for (y in 0 until h) {
            for (x in 0 until w) {
                Color.colorToHSV(px[y * w + x], hsv)
                if (hsv[0] >= hMin && hsv[0] <= hMax && hsv[1] >= sMin && hsv[2] >= vMin) {
                    cellN[(y / cs) * cw + (x / cs)]++
                    raw++
                }
            }
        }

        val seen = BooleanArray(cw * ch)
        val stack = IntArray(cw * ch)
        var best: Hit? = null
        var bestN = 0
        for (start in 0 until cw * ch) {
            if (cellN[start] == 0 || seen[start]) continue
            var sp = 0
            stack[sp++] = start
            seen[start] = true
            var n = 0
            var minX = cw
            var maxX = -1
            var minY = ch
            var maxY = -1
            while (sp > 0) {
                val cur = stack[--sp]
                val cx = cur % cw
                val cy = cur / cw
                n += cellN[cur]
                if (cx < minX) minX = cx
                if (cx > maxX) maxX = cx
                if (cy < minY) minY = cy
                if (cy > maxY) maxY = cy
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val nx = cx + dx
                        val ny = cy + dy
                        if (nx in 0 until cw && ny in 0 until ch) {
                            val ni = ny * cw + nx
                            if (cellN[ni] > 0 && !seen[ni]) { seen[ni] = true; stack[sp++] = ni }
                        }
                    }
                }
            }
            val bw = (maxX - minX + 1) * cs
            val bh = (maxY - minY + 1) * cs
            val aspect = bw.toFloat() / bh.toFloat()
            val fill = n.toFloat() / (bw * bh).toFloat()
            if (aspect in 0.6f..1.7f && fill <= maxFill && n > bestN) {
                bestN = n
                best = Hit(n, l + minX * cs + bw / 2, t + minY * cs + bh / 2, raw)
            }
        }
        return best ?: Hit(0, 0, 0, raw)
    }

    /** Verilen alandaki sari piksel sayisi (yol cizgisi). */
    fun countYellow(bmp: Bitmap, area: Rect, c: Cfg): Int {
        val l = area.left.coerceIn(0, bmp.width - 2)
        val t = area.top.coerceIn(0, bmp.height - 2)
        val r = area.right.coerceIn(l + 1, bmp.width)
        val b = area.bottom.coerceIn(t + 1, bmp.height)
        val w = r - l
        val h = b - t
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, l, t, w, h)
        val hMin = c.f("yMin", 30f)
        val hMax = c.f("yMax", 50f)
        val sMin = c.f("ySat", 0.45f)
        val vMin = c.f("yVal", 0.5f)
        val hsv = FloatArray(3)
        var n = 0
        for (i in px.indices) {
            Color.colorToHSV(px[i], hsv)
            if (hsv[0] >= hMin && hsv[0] <= hMax && hsv[1] >= sMin && hsv[2] >= vMin) n++
        }
        return n
    }

    fun find(bmp: Bitmap, zone: Rect, c: Cfg): Hit? {
        val h = scan(bmp, zone, c)
        return if (h.n >= c.f("minPx", 40f).toInt()) h else null
    }
}
