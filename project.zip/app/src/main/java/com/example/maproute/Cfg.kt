package com.example.maproute

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Point
import android.graphics.Rect

const val WC = -2
const val MP = -1

class Cfg(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun f(k: String, d: Float): Float = sp.getFloat(k, d)
    fun put(k: String, v: Float) { sp.edit().putFloat(k, v).apply() }

    fun rect(k: String): Rect? {
        val s = sp.getString(k, null) ?: return null
        val p = s.split(",").mapNotNull { it.toIntOrNull() }
        return if (p.size == 4) Rect(p[0], p[1], p[2], p[3]) else null
    }
    fun putRect(k: String, r: Rect) {
        sp.edit().putString(k, "${r.left},${r.top},${r.right},${r.bottom}").apply()
    }

    fun point(k: String): Point? {
        val s = sp.getString(k, null) ?: return null
        val p = s.split(",").mapNotNull { it.toIntOrNull() }
        return if (p.size == 2) Point(p[0], p[1]) else null
    }
    fun putPoint(k: String, p: Point) {
        sp.edit().putString(k, "${p.x},${p.y}").apply()
    }

    fun circle(): FloatArray? {
        val s = sp.getString("circle", null) ?: return null
        val p = s.split(",").mapNotNull { it.toFloatOrNull() }
        return if (p.size == 3) floatArrayOf(p[0], p[1], p[2]) else null
    }
    fun putCircle(cx: Float, cy: Float, r: Float) {
        sp.edit().putString("circle", "$cx,$cy,$r").apply()
    }

    fun waypoints(): List<Point> {
        val s = sp.getString("route", "") ?: ""
        return s.split(";").mapNotNull { q ->
            val a = q.split(",").mapNotNull { it.toIntOrNull() }
            if (a.size == 2) Point(a[0], a[1]) else null
        }
    }
    fun putWaypoints(l: List<Point>) {
        sp.edit().putString("route", l.joinToString(";") { "${it.x},${it.y}" }).apply()
    }
}

data class Hit(val n: Int, val x: Int, val y: Int, val raw: Int = 0, val kind: Int = 0)

object Detector {
    /**
     * Bolgede verilen renk araligindaki pikselleri bulur, bagli parcalara ayirir.
     * Sadece halka benzeri (kareye yakin, ici bos) parcalar portal sayilir.
     * hollow=true ise parcanin ortasinin bos olmasi sart (diagonal cizgileri eler).
     */
    fun scanColor(
        bmp: Bitmap, zone: Rect,
        hMin: Float, hMax: Float, sMin: Float, vMin: Float,
        maxFill: Float, hollow: Boolean
    ): Hit {
        val l = zone.left.coerceIn(0, bmp.width - 2)
        val t = zone.top.coerceIn(0, bmp.height - 2)
        val r = zone.right.coerceIn(l + 1, bmp.width)
        val b = zone.bottom.coerceIn(t + 1, bmp.height)
        val w = r - l
        val h = b - t
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, l, t, w, h)

        val cs = 3
        val cw = (w + cs - 1) / cs
        val ch = (h + cs - 1) / cs
        val cellN = IntArray(cw * ch)
        val hsv = FloatArray(3)
        var raw = 0
        for (y in 0 until h) {
            for (x in 0 until w) {
                Color.colorToHSV(px[y * w + x], hsv)
                if (hsv[0] >= hMin && hsv[0] <= hMax && hsv[1] >= sMin && hsv[2] >= vMin) {
                    cellN[(y / cs) * cw + (x / cs)]++
                    raw++
                }
            }
        }

        val seen = BooleanArray(cw * ch)
        val stack = IntArray(cw * ch)
        val comp = IntArray(cw * ch)
        var best: Hit? = null
        var bestN = 0
        for (start in 0 until cw * ch) {
            if (cellN[start] == 0 || seen[start]) continue
            var sp = 0
            var cn = 0
            stack[sp++] = start
            seen[start] = true
            var n = 0
            var minX = cw
            var maxX = -1
            var minY = ch
            var maxY = -1
            while (sp > 0) {
                val cur = stack[--sp]
                comp[cn++] = cur
                val cx = cur % cw
                val cy = cur / cw
                n += cellN[cur]
                if (cx < minX) minX = cx
                if (cx > maxX) maxX = cx
                if (cy < minY) minY = cy
                if (cy > maxY) maxY = cy
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val nx = cx + dx
                        val ny = cy + dy
                        if (nx in 0 until cw && ny in 0 until ch) {
                            val ni = ny * cw + nx
                            if (cellN[ni] > 0 && !seen[ni]) { seen[ni] = true; stack[sp++] = ni }
                        }
                    }
                }
            }
            val bw = (maxX - minX + 1) * cs
            val bh = (maxY - minY + 1) * cs
            val aspect = bw.toFloat() / bh.toFloat()
            val fill = n.toFloat() / (bw * bh).toFloat()
            var hollowOk = true
            if (hollow) {
                val wC = (maxX - minX + 1).toFloat()
                val hC = (maxY - minY + 1).toFloat()
                val x0 = minX + wC * 0.3f
                val x1 = maxX - wC * 0.3f
                val y0 = minY + hC * 0.3f
                val y1 = maxY - hC * 0.3f
                var center = 0
                for (k in 0 until cn) {
                    val c = comp[k]
                    val cx = (c % cw).toFloat()
                    val cy = (c / cw).toFloat()
                    if (cx >= x0 && cx <= x1 && cy >= y0 && cy <= y1) center += cellN[c]
                }
                hollowOk = center <= n * 0.08f
            }
            if (aspect in 0.6f..1.7f && fill <= maxFill && hollowOk && n > bestN) {
                bestN = n
                best = Hit(n, l + minX * cs + bw / 2, t + minY * cs + bh / 2, raw)
            }
        }
        return best ?: Hit(0, 0, 0, raw)
    }

    /** Mavi portal. */
    fun scan(bmp: Bitmap, zone: Rect, c: Cfg): Hit =
        scanColor(bmp, zone, c.f("hMin", 180f), c.f("hMax", 220f), c.f("sMin", 0.45f), c.f("vMin", 0.5f), c.f("maxFill", 0.6f), false)

    fun find(bmp: Bitmap, zone: Rect, c: Cfg): Hit? {
        val h = scan(bmp, zone, c)
        return if (h.n >= c.f("minPx", 40f).toInt()) h else null
    }

    /** Sari portal. */
    fun scanYellow(bmp: Bitmap, zone: Rect, c: Cfg): Hit =
        scanColor(
            bmp, zone, c.f("pyMin", 30f), c.f("pyMax", 50f), c.f("pySat", 0.45f), c.f("pyVal", 0.5f),
            c.f("maxFill", 0.6f), c.f("pyHollow", 1f) >= 0.5f
        )

    fun findYellow(bmp: Bitmap, zone: Rect, c: Cfg): Hit? {
        val h = scanYellow(bmp, zone, c)
        return if (h.n >= c.f("pyPx", 40f).toInt()) h else null
    }

    /** Verilen alandaki sari piksel sayisi (yol cizgisi). */
    fun countYellow(bmp: Bitmap, area: Rect, c: Cfg, exclude: Rect? = null): Int {
        val l = area.left.coerceIn(0, bmp.width - 2)
        val t = area.top.coerceIn(0, bmp.height - 2)
        val r = area.right.coerceIn(l + 1, bmp.width)
        val b = area.bottom.coerceIn(t + 1, bmp.height)
        val w = r - l
        val h = b - t
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, l, t, w, h)
        val hMin = c.f("yMin", 30f)
        val hMax = c.f("yMax", 50f)
        val sMin = c.f("ySat", 0.45f)
        val vMin = c.f("yVal", 0.5f)
        val hsv = FloatArray(3)
        var n = 0
        for (i in px.indices) {
            if (exclude != null && exclude.contains(l + (i % w), t + (i / w))) continue
            Color.colorToHSV(px[i], hsv)
            if (hsv[0] >= hMin && hsv[0] <= hMax && hsv[1] >= sMin && hsv[2] >= vMin) n++
        }
        return n
    }
}
