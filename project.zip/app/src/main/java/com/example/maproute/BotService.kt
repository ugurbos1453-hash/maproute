package com.example.maproute

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class BotService : Service() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var cfg: Cfg
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var curW = 0
    private var curH = 0
    private var lastBmp: Bitmap? = null
    private var panel: View? = null
    private var calib: View? = null
    private var stopping = false
    @Volatile private var running = false
    @Volatile private var ignoreUntil = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null || intent == null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        cfg = Cfg(this)
        startFg()
        val code = intent.getIntExtra("code", 0)
        val data = readData(intent)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { running = false; ui.post { stopSelf() } }
        }, ui)
        showPanel()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra<Intent>("data")

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "MapRoute", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bot")
            .setContentTitle("MapRoute calisiyor")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun toast(s: String) { ui.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() } }

    // ---------- Panel ----------
    private fun showPanel() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xCC222222.toInt())
            setPadding(6, 6, 6, 6)
        }
        val lp = WindowManager.LayoutParams(
            WC, WC, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }

        var dx = 0f
        var dy = 0f
        val handle = TextView(this).apply {
            text = " ::: "
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = lp.x - e.rawX; dy = lp.y - e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = (e.rawX + dx).toInt(); lp.y = (e.rawY + dy).toInt()
                        wm.updateViewLayout(row, lp)
                    }
                }
                true
            }
        }
        row.addView(handle)
        fun btn(t: String, a: () -> Unit) {
            row.addView(Button(this).apply {
                text = t; textSize = 11f; isAllCaps = false
                minWidth = 0; minimumWidth = 0
                setOnClickListener { a() }
            })
        }
        btn("Bolge") { startCalib(0) }
        btn("Atla") { startCalib(1) }
        btn("Rota") { startCalib(2) }
        btn("Test") { runTest() }
        btn("Baslat") { startBot() }
        btn("Durdur") { running = false; toast("Durduruldu") }
        btn("X") { stopSelf() }
        panel = row
        wm.addView(row, lp)
    }

    private fun startCalib(mode: Int) {
        running = false
        panel?.visibility = View.GONE
        val v = CalibView(this, cfg, mode) {
            ui.post {
                calib?.let { try { wm.removeView(it) } catch (_: Exception) {} }
                calib = null
                panel?.visibility = View.VISIBLE
            }
        }
        calib = v
        wm.addView(v, WindowManager.LayoutParams(
            MP, MP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ))
    }

    private fun runTest() {
        Thread {
            if (cfg.rect("zone") == null) { toast("Once Bolge ciz"); return@Thread }
            val h = detect()
            toast(if (h == null) "Portal yok (veya ekran alinamadi)" else "Portal var: ${h.n}px @ ${h.x},${h.y}")
        }.start()
    }

    private fun startBot() {
        if (running) return
        running = true
        toast("Basladi")
        Thread { runLoop() }.start()
    }

    // ---------- Ekran yakalama ----------
    @Suppress("DEPRECATION")
    private fun ensureDisplay(): Boolean {
        val proj = projection ?: return false
        val dm = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        if (vd != null && w == curW && h == curH) return true
        reader?.close()
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val existing = vd
        if (existing == null) {
            vd = proj.createVirtualDisplay(
                "cap", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
        } else {
            existing.resize(w, h, dm.densityDpi)
            existing.surface = r.surface
        }
        reader = r
        curW = w
        curH = h
        lastBmp?.recycle()
        lastBmp = null
        return true
    }

    private fun grab(): Bitmap? {
        if (!ensureDisplay()) return null
        var tries = 0
        while (tries < 15) {
            val img = reader?.acquireLatestImage()
            if (img != null) {
                try {
                    val pl = img.planes[0]
                    val pw = pl.rowStride / pl.pixelStride
                    val bmp = Bitmap.createBitmap(pw, img.height, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(pl.buffer)
                    lastBmp?.recycle()
                    lastBmp = bmp
                } finally {
                    img.close()
                }
                return lastBmp
            }
            if (lastBmp != null) return lastBmp
            Thread.sleep(100)
            tries++
        }
        return lastBmp
    }

    @Synchronized
    private fun detect(): Hit? {
        val zone = cfg.rect("zone") ?: return null
        val bmp = grab() ?: return null
        return Detector.find(bmp, zone, cfg)
    }

    // ---------- Bot dongusu ----------
    private fun pause(ms: Long) {
        var t = 0L
        while (running && t < ms) { Thread.sleep(100); t += 100 }
    }

    private fun tap(x: Int, y: Int) {
        pause((200..800).random().toLong())
        if (!running) return
        val s = TapService.instance
        if (s == null) { toast("Erisilebilirlik servisi kapali"); running = false; return }
        s.tapBlocking(x + (-3..3).random(), y + (-3..3).random())
    }

    private fun waitForPortal(sec: Float): Hit? {
        var t = 0L
        while (running && t < (sec * 1000).toLong()) {
            pause(500)
            t += 500
            if (System.currentTimeMillis() > ignoreUntil) {
                val h = detect()
                if (h != null) return h
            }
        }
        return null
    }

    private fun runLoop() {
        val wps = cfg.waypoints()
        val jump = cfg.point("jump")
        if (cfg.rect("zone") == null || jump == null || wps.isEmpty()) {
            toast("Once Bolge, Atla ve Rota kalibre et")
            running = false
            return
        }
        val start = System.currentTimeMillis()
        val maxMs = (cfg.f("maxMin", 60f) * 60_000f).toLong()
        var idx = 0
        var fails = 0
        var hit: Hit? = null
        while (running) {
            if (System.currentTimeMillis() - start > maxMs) { toast("Sure doldu, durdu"); break }
            if (hit == null && System.currentTimeMillis() > ignoreUntil) hit = detect()
            val h = hit
            if (h != null) {
                tap(h.x, h.y)
                pause((cfg.f("travel", 6f) * 1000).toLong())
                tap(jump.x, jump.y)
                pause(3000)
                if (running && detect() != null) {
                    fails++
                    if (fails >= 3) { ignoreUntil = System.currentTimeMillis() + 30_000; fails = 0 }
                } else {
                    fails = 0
                }
                hit = null
                continue
            }
            val p = wps[idx]
            idx = (idx + 1) % wps.size
            tap(p.x, p.y)
            hit = waitForPortal(cfg.f("wait", 8f))
        }
        running = false
    }

    override fun onDestroy() {
        if (stopping) return
        stopping = true
        running = false
        if (::wm.isInitialized) {
            panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            calib?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        }
        vd?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
