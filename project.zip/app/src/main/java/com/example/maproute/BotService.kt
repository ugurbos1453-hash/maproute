package com.example.maproute

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.ImageReader
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class BotService : Service() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var cfg: Cfg
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var curW = 0
    private var curH = 0
    private var lastBmp: Bitmap? = null

    private var panel: View? = null
    private var calib: View? = null
    private var dialog: View? = null
    private var marker: MarkerView? = null
    private var stats: TextView? = null
    private var statsLp: WindowManager.LayoutParams? = null
    private var statsPos = 0
    private var statusDot: TextView? = null
    private var pauseBtn: Button? = null
    private var stopping = false

    // ---- calisma durumu ----
    @Volatile private var running = false
        set(v) {
            field = v
            refreshStatus()
        }
    @Volatile private var paused = false
    @Volatile private var pauseStart = 0L
    @Volatile private var pausedAccum = 0L
    @Volatile private var ignoreUntil = 0L
    private var theta = -Math.PI / 2   // dairede mevcut aci (baslangic: ust nokta)

    // ---- uyari (dolu mavi daire) ----
    @Volatile private var alertActive = false
    private var alertArmed = true
    private var alertHits = 0
    private var lastAlertSeen = 0L
    private var lastAlertCheck = 0L
    private var alertView: View? = null
    private var player: MediaPlayer? = null
    private var tone: ToneGenerator? = null
    private var blinkOn = false

    // ---- istatistik / mod ----
    @Volatile private var runStartMs = 0L
    @Volatile private var runEndMs = 0L
    @Volatile private var jumpCount = 0
    @Volatile private var yJumps = 0
    @Volatile private var standN = 0          // basta sorulan sayi: bu kadar portal atlanana kadar rotaya cikma
    @Volatile private var standManual = false // sari portal sonrasi vb.: "Rotaya gec"e kadar bekle

    private fun standing(): Boolean = standManual || jumpCount < standN

    private fun fmt(sec: Long): String =
        String.format("%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)

    private fun refreshStatus() {
        ui.post {
            val c = if (!running) 0xFFFF5252.toInt() else if (paused) 0xFFFFC107.toInt() else 0xFF4CAF50.toInt()
            statusDot?.setTextColor(c)
            pauseBtn?.text = if (paused) "Devam" else "Beklet"
        }
    }

    @Synchronized
    private fun setPaused(v: Boolean) {
        if (v == paused) return
        val now = System.currentTimeMillis()
        if (v) pauseStart = now else pausedAccum += now - pauseStart
        paused = v
        refreshStatus()
    }

    private fun togglePause() {
        if (!running) { toast("Bot calismiyor"); return }
        setPaused(!paused)
        toast(if (paused) "Beklemede (hicbir sey sifirlanmadi)" else "Devam ediyor")
    }

    private fun leaveStanding() {
        standManual = false
        standN = 0
        toast("Rotaya gecildi")
    }

    private val statsTick: Runnable = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            val end = if (running) now else (if (runEndMs > 0) runEndMs else runStartMs)
            val curPause = if (paused && pauseStart > 0) now - pauseStart else 0L
            val el = if (runStartMs > 0) ((end - runStartMs - pausedAccum - curPause) / 1000).coerceAtLeast(0) else 0L
            val avg = if (jumpCount > 0) fmt(el / jumpCount) + " / portal" else "-"
            val mode = when {
                !running -> "Durdu"
                paused -> "Beklet"
                standManual -> "Bekleme modu"
                jumpCount < standN -> "Bekleme ($jumpCount/$standN)"
                else -> "Rota"
            }
            val ys = if (yJumps > 0) " (sarı: $yJumps)" else ""
            val cal = java.util.Calendar.getInstance()
            val tot = cal.get(java.util.Calendar.MINUTE) * 60 + cal.get(java.util.Calendar.SECOND)
            val rem = (3600 - tot) % 3600
            val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
            val nh = if (tot == 0) hour else (hour + 1) % 24
            val cd = String.format("%02d:00'a kalan: %02d:%02d", nh, rem / 60, rem % 60)
            stats?.text = "Mod: $mode\nSüre: ${fmt(el)}\nAtlanan portal: $jumpCount$ys\nOrtalama: $avg\n$cd"
            ui.postDelayed(this, 1000)
        }
    }

    private fun cycleStats() {
        val st = stats ?: return
        val lp = statsLp ?: return
        statsPos = (statsPos + 1) % 6
        if (statsPos == 5) { st.visibility = View.GONE; return }
        st.visibility = View.VISIBLE
        lp.gravity = when (statsPos) {
            0 -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            1 -> Gravity.BOTTOM or Gravity.END
            2 -> Gravity.TOP or Gravity.END
            3 -> Gravity.TOP or Gravity.START
            else -> Gravity.BOTTOM or Gravity.START
        }
        wm.updateViewLayout(st, lp)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null || intent == null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        cfg = Cfg(this)
        startFg()
        val code = intent.getIntExtra("code", 0)
        val data = readData(intent)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { running = false; ui.post { stopSelf() } }
        }, ui)
        showPanel()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra<Intent>("data")

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "MapRoute", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bot")
            .setContentTitle("MapRoute calisiyor")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun toast(s: String) { ui.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() } }

    // ---------- Panel ----------
    private fun mark(x: Int, y: Int, color: Int, dur: Long) {
        if (cfg.f("dbg", 1f) < 0.5f) return
        ui.post { marker?.add(x, y, color, dur) }
    }

    private fun showPanel() {
        val mv = MarkerView(this)
        marker = mv
        wm.addView(mv, WindowManager.LayoutParams(
            MP, MP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ))

        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD1E1E1E.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val lp = WindowManager.LayoutParams(
            WC, WC, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }

        fun btn(t: String, minW: Int, a: () -> Unit): Button = Button(this).apply {
            text = t
            textSize = 12f
            isAllCaps = false
            minWidth = 0
            minimumWidth = dp(minW)
            minHeight = 0
            minimumHeight = dp(36)
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { a() }
        }
        fun section(t: String) = TextView(this).apply {
            text = t
            textSize = 11f
            setTextColor(0xFFAAAAAA.toInt())
            setPadding(dp(4), dp(6), 0, dp(2))
        }
        fun row(vararg b: Button) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            for (x in b) addView(x)
        }

        var dx = 0f
        var dy = 0f
        val handle = TextView(this).apply {
            text = "::"
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(8), 0, dp(10), 0)
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = lp.x - e.rawX; dy = lp.y - e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = (e.rawX + dx).toInt(); lp.y = (e.rawY + dy).toInt()
                        wm.updateViewLayout(root, lp)
                    }
                }
                true
            }
        }
        val dot = TextView(this).apply {
            text = "●"
            textSize = 16f
            setTextColor(0xFFFF5252.toInt())
            setPadding(0, 0, dp(6), 0)
        }
        statusDot = dot

        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        fun closeMenu() { menu.visibility = View.GONE }
        menu.addView(section("Kalibrasyon"))
        menu.addView(row(
            btn("Portal alanı", 104) { closeMenu(); startCalib(0) },
            btn("Sarı portal alanı", 104) { closeMenu(); startCalib(5) }
        ))
        menu.addView(row(
            btn("Harita tuşu", 104) { closeMenu(); startCalib(3) },
            btn("Atlama tuşu", 104) { closeMenu(); startCalib(1) }
        ))
        menu.addView(row(
            btn("Rota (daire)", 104) { closeMenu(); startCalib(2) },
            btn("Uyarı alanı", 104) { closeMenu(); startCalib(6) }
        ))
        menu.addView(section("Araçlar"))
        menu.addView(row(
            btn("Test", 104) { runTest() },
            btn("İstatistik", 104) { cycleStats() }
        ))
        menu.addView(row(
            btn("Rotaya geç", 104) { closeMenu(); leaveStanding() },
            btn("Kapat", 104) { stopSelf() }
        ))

        val pb = btn("Beklet", 56) { togglePause() }
        pauseBtn = pb
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(handle)
            addView(dot)
            addView(btn("Başlat", 56) { closeMenu(); askStartCount() })
            addView(pb)
            addView(btn("Durdur", 56) {
                if (running) { running = false; toast("Durduruldu (sayaçlar sıfırlanır)") }
            })
            addView(btn("Menü", 48) {
                menu.visibility = if (menu.visibility == View.GONE) View.VISIBLE else View.GONE
            })
        }
        root.addView(top)
        root.addView(menu)
        panel = root
        wm.addView(root, lp)

        val st = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        stats = st
        val slp = WindowManager.LayoutParams(
            WC, WC, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL }
        statsLp = slp
        wm.addView(st, slp)
        ui.post(statsTick)
    }

    // ---------- Baslat: "kac portal atlanana kadar bekle" sorusu ----------
    private fun closeDialog() {
        dialog?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        dialog = null
    }

    private fun askStartCount() {
        if (running) { toast("Zaten calisiyor (Beklet / Durdur kullan)"); return }
        if (dialog != null) return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        var n = cfg.f("startN", 0f).toInt().coerceIn(0, 99)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEE222222.toInt())
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        box.addView(TextView(this).apply {
            text = "Rotaya geçmeden önce kaç portal atlansın?\n(0 = hemen rota)"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
        })
        val num = TextView(this).apply {
            text = "$n"
            textSize = 32f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
        }
        box.addView(num)
        fun step(label: String, delta: Int): Button = Button(this).apply {
            text = label
            isAllCaps = false
            minWidth = 0
            minimumWidth = dp(56)
            setOnClickListener { n = (n + delta).coerceIn(0, 99); num.text = "$n" }
        }
        box.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(step("-5", -5))
            addView(step("-1", -1))
            addView(step("+1", 1))
            addView(step("+5", 5))
        })
        box.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(Button(this@BotService).apply {
                text = "Başlat"
                isAllCaps = false
                setOnClickListener {
                    cfg.put("startN", n.toFloat())
                    closeDialog()
                    standN = n
                    startBot()
                }
            })
            addView(Button(this@BotService).apply {
                text = "İptal"
                isAllCaps = false
                setOnClickListener { closeDialog() }
            })
        })
        dialog = box
        wm.addView(box, WindowManager.LayoutParams(
            WC, WC, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER })
    }

    private fun startCalib(mode: Int) {
        running = false
        panel?.visibility = View.GONE
        val v = CalibView(this, cfg, mode) {
            ui.post {
                calib?.let { try { wm.removeView(it) } catch (_: Exception) {} }
                calib = null
                panel?.visibility = View.VISIBLE
            }
        }
        calib = v
        wm.addView(v, WindowManager.LayoutParams(
            MP, MP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ))
    }

    private fun runTest() {
        Thread {
            if (cfg.rect("zone") == null) { toast("Once Portal alani ciz"); return@Thread }
            val s = scanNow()
            val minPx = cfg.f("minPx", 40f).toInt()
            if (s == null) { toast("Ekran alinamadi"); return@Thread }
            val ok = s.n >= minPx
            if (ok) mark(s.x, s.y, Color.MAGENTA, 2500)
            var yp = ""
            val ys = scanYellowNow()
            if (ys != null) {
                val pyPx = cfg.f("pyPx", 40f).toInt()
                val yok = ys.n >= pyPx
                if (yok) mark(ys.x, ys.y, Color.MAGENTA, 2500)
                yp = " | SARI PORTAL: ${ys.n}px, toplam sari: ${ys.raw} (esik $pyPx) -> " + (if (yok) "VAR @ ${ys.x},${ys.y}" else "yok")
            }
            var ap = ""
            val asc = scanAlertNow()
            if (asc != null) {
                val aPx = cfg.f("aPx", 60f).toInt()
                val aok = asc.n >= aPx
                if (aok) mark(asc.x, asc.y, Color.MAGENTA, 2500)
                ap = " | UYARI dolu mavi daire: ${asc.n}px (esik $aPx) -> " + (if (aok) "VAR @ ${asc.x},${asc.y}" else "yok")
            }
            toast("Mavi portal: ${s.n}px, toplam mavi: ${s.raw} (esik $minPx) -> " + (if (ok) "VAR @ ${s.x},${s.y}" else "yok") + yp + ap)
        }.start()
    }

    private fun startBot() {
        if (running) return
        running = true
        Thread {
            if (cfg.rect("zone") != null) {
                val s = scanNow()
                val minPx = cfg.f("minPx", 40f).toInt()
                if (s != null && s.n >= minPx) {
                    if (standN > 0) {
                        toast("Bolgede portal gorunuyor, hemen gidecek")
                    } else {
                        toast("Bolgede su an ${s.n}px mavi var (esik $minPx). Portal yokken baslat ya da esigi yukselt.")
                        running = false
                        return@Thread
                    }
                }
            }
            toast("Basladi")
            jumpCount = 0
            yJumps = 0
            standManual = false
            paused = false
            alertArmed = true
            alertHits = 0
            lastAlertSeen = 0L
            pauseStart = 0L
            pausedAccum = 0L
            runEndMs = 0L
            runStartMs = System.currentTimeMillis()
            runLoop()
        }.start()
    }

    // ---------- Ekran yakalama ----------
    @Suppress("DEPRECATION")
    private fun ensureDisplay(): Boolean {
        val proj = projection ?: return false
        val dm = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        if (vd != null && w == curW && h == curH) return true
        reader?.close()
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val existing = vd
        if (existing == null) {
            vd = proj.createVirtualDisplay(
                "cap", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
        } else {
            existing.resize(w, h, dm.densityDpi)
            existing.surface = r.surface
        }
        reader = r
        curW = w
        curH = h
        lastBmp?.recycle()
        lastBmp = null
        return true
    }

    private fun grab(): Bitmap? {
        if (!ensureDisplay()) return null
        var tries = 0
        while (tries < 15) {
            val img = reader?.acquireLatestImage()
            if (img != null) {
                try {
                    val pl = img.planes[0]
                    val pw = pl.rowStride / pl.pixelStride
                    val bmp = Bitmap.createBitmap(pw, img.height, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(pl.buffer)
                    lastBmp?.recycle()
                    lastBmp = bmp
                } finally {
                    img.close()
                }
                return lastBmp
            }
            if (lastBmp != null) return lastBmp
            Thread.sleep(100)
            tries++
        }
        return lastBmp
    }

    @Synchronized
    private fun scanNow(): Hit? {
        val zone = cfg.rect("zone") ?: return null
        val bmp = grab() ?: return null
        return Detector.scan(bmp, zone, cfg)
    }

    @Synchronized
    private fun scanYellowNow(): Hit? {
        val zone = cfg.rect("yzone") ?: return null
        val bmp = grab() ?: return null
        return Detector.scanYellow(bmp, zone, cfg)
    }

    // ---------- Uyari: dolu mavi daire ----------
    @Synchronized
    private fun scanAlertNow(): Hit? {
        val zone = cfg.rect("azone") ?: return null
        val bmp = grab() ?: return null
        return Detector.scanFilled(bmp, zone, cfg)
    }

    /** Rotada/beklemede dolu mavi daire var mi bakar; 2 ardisik gorunce alarm verir. */
    private fun checkAlert() {
        if (!running || paused || alertActive) return
        if (cfg.f("alert", 1f) < 0.5f || cfg.rect("azone") == null) return
        val now = System.currentTimeMillis()
        if (now - lastAlertCheck < 500) return
        lastAlertCheck = now
        val h = scanAlertNow()
        if (h != null && h.n >= cfg.f("aPx", 60f).toInt()) {
            lastAlertSeen = now
            alertHits++
            if (alertArmed && alertHits >= 2) triggerAlert(h)
        } else {
            alertHits = 0
            // ayni nesne yerinde dururken tekrar tekrar calmasin: 3 sn gorunmeyince yeniden hazir
            if (!alertArmed && now - lastAlertSeen > 3000) alertArmed = true
        }
    }

    private fun triggerAlert(h: Hit) {
        alertActive = true
        alertArmed = false
        setPaused(true)
        mark(h.x, h.y, Color.MAGENTA, 4000)
        ui.post { showAlertBanner(); startAlarm() }
    }

    private val blinkTick: Runnable = object : Runnable {
        override fun run() {
            val v = alertView ?: return
            blinkOn = !blinkOn
            v.setBackgroundColor(if (blinkOn) 0xF0FF6F00.toInt() else 0xF0C62828.toInt())
            ui.postDelayed(this, 500)
        }
    }

    private val beepTick: Runnable = object : Runnable {
        override fun run() {
            tone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500)
            ui.postDelayed(this, 900)
        }
    }

    private fun showAlertBanner() {
        if (alertView != null) return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xF0C62828.toInt())
            setPadding(dp(20), dp(14), dp(20), dp(14))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        box.addView(TextView(this).apply {
            text = "DİKKAT!"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER_HORIZONTAL
        })
        box.addView(TextView(this).apply {
            text = "Ekranda dolu mavi daire görüldü.\nBot beklemeye alındı."
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(6), 0, dp(10))
        })
        box.addView(Button(this).apply {
            text = "Tamam"
            isAllCaps = false
            textSize = 18f
            setOnClickListener {
                stopAlarm()
                toast("Uyarı kapatıldı. Hazır olunca Devam'a bas")
            }
        })
        alertView = box
        wm.addView(box, WindowManager.LayoutParams(
            WC, WC, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(80) })
        ui.post(blinkTick)
    }

    private fun startAlarm() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            try {
                tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)
                ui.post(beepTick)
            } catch (_: Exception) {}
        }
    }

    /** Sesi ve uyari penceresini kapatir (Tamam). */
    private fun stopAlarm() {
        alertActive = false
        ui.removeCallbacks(beepTick)
        ui.removeCallbacks(blinkTick)
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        try { tone?.release() } catch (_: Exception) {}
        tone = null
        alertView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        alertView = null
    }

    /** Mavi portal alani, sonra (varsa) sari portal alani. kind: 0 mavi, 1 sari. */
    @Synchronized
    private fun detect(): Hit? {
        val bmp = grab() ?: return null
        val z = cfg.rect("zone")
        if (z != null) {
            val h = Detector.find(bmp, z, cfg)
            if (h != null) return h
        }
        val yz = cfg.rect("yzone")
        if (yz != null) {
            val h = Detector.findYellow(bmp, yz, cfg)
            if (h != null) return h.copy(kind = 1)
        }
        return null
    }

    // ---------- Bot dongusu ----------
    /** ms kadar bekler; Beklet'teyken sure islemez (devam edince kaldigi yerden). */
    private fun pause(ms: Long) {
        var t = 0L
        while (running && t < ms) {
            Thread.sleep(100)
            if (!paused) t += 100
        }
    }

    private fun waitIfPaused() {
        while (running && paused) Thread.sleep(100)
    }

    private fun tap(x: Int, y: Int) {
        waitIfPaused()
        val dMin = cfg.f("dMin", 200f).toInt()
        val dMax = cfg.f("dMax", 800f).toInt()
        if (dMax > 0) pause(if (dMax > dMin) (dMin..dMax).random().toLong() else dMax.toLong())
        if (!running) return
        val s = TapService.instance
        if (s == null) { toast("Erisilebilirlik servisi kapali"); running = false; return }
        val tx = x + (-3..3).random()
        val ty = y + (-3..3).random()
        mark(tx, ty, Color.RED, 700)
        if (!s.tapBlocking(tx, ty)) {
            pause(150)
            if (running) s.tapBlocking(tx, ty)
        }
    }

    private fun waitForPortal(sec: Float): Hit? {
        var t = 0L
        while (running && t < (sec * 1000).toLong()) {
            pause(500)
            t += 500
            if (System.currentTimeMillis() > ignoreUntil) {
                val h = detect()
                if (h != null) return h
            }
        }
        return null
    }

    /** Daire uzerinde ~1,5 sn'lik bir yay surukler. Surerken portal gorurse Hit doner. */
    private fun dragCircleChunk(cx: Float, cy: Float, r: Float, speed: Float, dir: Int): Hit? {
        val s = TapService.instance
        if (s == null) { toast("Erisilebilirlik servisi kapali"); running = false; return null }
        val chunkMs = 1500L
        val arc = speed * chunkMs / 1000f
        val dTheta = dir * arc / r
        val steps = kotlin.math.ceil(kotlin.math.abs(dTheta) / 0.1).toInt().coerceAtLeast(2)
        val xs = IntArray(steps + 1)
        val ys = IntArray(steps + 1)
        for (i in 0..steps) {
            val a = theta + dTheta * i / steps
            xs[i] = (cx + r * kotlin.math.cos(a)).toInt()
            ys[i] = (cy + r * kotlin.math.sin(a)).toInt()
        }
        val h = dragPath(s, xs, ys, chunkMs)
        if (running) {
            theta += dTheta
            if (theta > 2 * Math.PI) theta -= 2 * Math.PI
            if (theta < -2 * Math.PI) theta += 2 * Math.PI
        }
        return h
    }

    private fun dragPath(s: TapService, xs: IntArray, ys: IntArray, ms: Long): Hit? {
        var tries = 0
        while (running && tries < 3) {
            tries++
            waitIfPaused()
            if (!running) return null
            val latch = java.util.concurrent.CountDownLatch(1)
            var ok = false
            mark(xs[xs.size - 1], ys[ys.size - 1], Color.RED, ms.coerceAtMost(2000L))
            val sent = s.dragPathAsync(xs, ys, ms) { r -> ok = r; latch.countDown() }
            if (!sent) { pause(200); continue }
            var found: Hit? = null
            while (running) {
                if (latch.await(250, java.util.concurrent.TimeUnit.MILLISECONDS)) break
                checkAlert()
                if (found == null && System.currentTimeMillis() > ignoreUntil) found = detect()
            }
            if (found != null) return found   // parca bitti, parmak kalkti
            if (ok || !running) return null
            pause(150)
        }
        return null
    }

    private fun confirm(h: Hit): Hit? {
        var cur = h
        repeat(3) {
            pause(400)
            if (!running) return null
            val n = detect() ?: return null
            if (n.kind != h.kind || kotlin.math.abs(n.x - h.x) > 12 || kotlin.math.abs(n.y - h.y) > 12) return null
            cur = n
        }
        return cur
    }

    private fun afterYellow() {
        when (cfg.f("yAfter", 1f).toInt()) {
            1 -> { toast("Sari portal atlandi: beklemede (Devam'a bas)"); setPaused(true) }
            2 -> { standManual = true; toast("Sari portal atlandi: bekleme modu (Rotaya gec ile cik)") }
            else -> toast("Sari portal atlandi")
        }
    }

    private fun runLoop() {
        try {
            loopBody()
        } catch (e: Throwable) {
            toast("Hata: ${e.javaClass.simpleName} ${e.message}")
        } finally {
            setPaused(false)
            running = false
            runEndMs = System.currentTimeMillis()
            toast("Dongu durdu")
        }
    }

    private fun loopBody() {
        val jump = cfg.point("jump")
        val mapBtn = cfg.point("mapbtn")
        if (cfg.rect("zone") == null || jump == null || cfg.circle() == null) {
            toast("Once Portal alani, Atlama tusu ve Rota (daire) kalibre et")
            return
        }
        val start = System.currentTimeMillis()
        val maxMs = (cfg.f("maxMin", 60f) * 60_000f).toLong()
        var fails = 0
        var pending: Hit? = null
        theta = -Math.PI / 2
        while (running) {
            waitIfPaused()
            if (!running) break
            checkAlert()
            waitIfPaused()
            if (!running) break
            if (System.currentTimeMillis() - start - pausedAccum > maxMs) { toast("Sure doldu, durdu"); break }
            val cand = pending ?: (if (System.currentTimeMillis() > ignoreUntil) detect() else null)
            pending = null
            val h = if (cand != null) confirm(cand) else null
            if (h != null) {
                val yellow = h.kind == 1
                toast((if (yellow) "SARI portal bulundu" else "Portal bulundu") + " (${h.n}px) @ ${h.x},${h.y}")
                mark(h.x, h.y, Color.MAGENTA, 1500)
                // 1) haritada portalin ortasina tikla ve varmasini bekle (sure ayarlardan)
                tap(h.x, h.y)
                pause(((if (yellow) cfg.f("ytravel", 20f) else cfg.f("travel", 8f)) * 1000).toLong())
                // 2) haritayi kapat
                if (mapBtn != null) { tap(mapBtn.x, mapBtn.y); pause(1000) }
                // 3) atlama butonuna 2 kez, 1 sn arayla
                tap(jump.x, jump.y)
                pause(1000)
                tap(jump.x, jump.y)
                pause(1500)
                // 4) haritayi tekrar ac
                if (mapBtn != null) { tap(mapBtn.x, mapBtn.y); pause(1500) }
                if (running && detect() != null) {
                    fails++
                    if (fails >= 3) { ignoreUntil = System.currentTimeMillis() + 30_000; fails = 0 }
                } else {
                    fails = 0
                    if (running) {
                        jumpCount++
                        if (yellow) {
                            yJumps++
                            afterYellow()
                        } else {
                            toast("Portal atlandi (toplam $jumpCount)")
                        }
                    }
                }
                continue
            }
            // Bekleme modu: rotada ilerleme, sadece portal bekle
            if (standing()) { pause(300); continue }

            // Rota: daire uzerinde surukle
            val c = cfg.circle()
            if (c != null) {
                pending = dragCircleChunk(
                    c[0], c[1], c[2],
                    cfg.f("dragSpeed", 37f).coerceAtLeast(1f),
                    if (cfg.f("circleDir", 1f) >= 0f) 1 else -1
                )
            }
        }
    }

    override fun onDestroy() {
        if (stopping) return
        stopping = true
        running = false
        if (::wm.isInitialized) {
            panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            calib?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            dialog?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            stats?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            ui.removeCallbacks(statsTick)
            stopAlarm()
        }
        vd?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
