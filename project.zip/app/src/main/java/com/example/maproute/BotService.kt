package com.example.maproute

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class BotService : Service() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var cfg: Cfg
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var curW = 0
    private var curH = 0
    private var lastBmp: Bitmap? = null
    private var panel: View? = null
    private var calib: View? = null
    private var marker: MarkerView? = null
    private var stopping = false
    private var statusDot: TextView? = null
    @Volatile private var running = false
        set(v) {
            field = v
            ui.post { statusDot?.setTextColor(if (v) 0xFF4CAF50.toInt() else 0xFFFF5252.toInt()) }
        }
    @Volatile private var ignoreUntil = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null || intent == null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        cfg = Cfg(this)
        startFg()
        val code = intent.getIntExtra("code", 0)
        val data = readData(intent)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { running = false; ui.post { stopSelf() } }
        }, ui)
        showPanel()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra<Intent>("data")

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "MapRoute", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bot")
            .setContentTitle("MapRoute calisiyor")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun toast(s: String) { ui.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() } }

    // ---------- Panel ----------
    private fun mark(x: Int, y: Int, color: Int, dur: Long) {
        if (cfg.f("dbg", 1f) < 0.5f) return
        ui.post { marker?.add(x, y, color, dur) }
    }

    private fun showPanel() {
        val mv = MarkerView(this)
        marker = mv
        wm.addView(mv, WindowManager.LayoutParams(
            MP, MP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ))

        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD1E1E1E.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val lp = WindowManager.LayoutParams(
            WC, WC, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }

        fun btn(t: String, minW: Int, a: () -> Unit): Button = Button(this).apply {
            text = t
            textSize = 12f
            isAllCaps = false
            minWidth = 0
            minimumWidth = dp(minW)
            minHeight = 0
            minimumHeight = dp(36)
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { a() }
        }
        fun section(t: String) = TextView(this).apply {
            text = t
            textSize = 11f
            setTextColor(0xFFAAAAAA.toInt())
            setPadding(dp(4), dp(6), 0, dp(2))
        }
        fun row(vararg b: Button) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            for (x in b) addView(x)
        }

        // Ust satir: surukle, durum, Baslat, Durdur, Menu
        var dx = 0f
        var dy = 0f
        val handle = TextView(this).apply {
            text = "::"
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(8), 0, dp(10), 0)
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = lp.x - e.rawX; dy = lp.y - e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = (e.rawX + dx).toInt(); lp.y = (e.rawY + dy).toInt()
                        wm.updateViewLayout(root, lp)
                    }
                }
                true
            }
        }
        val dot = TextView(this).apply {
            text = "●"
            textSize = 16f
            setTextColor(0xFFFF5252.toInt())
            setPadding(0, 0, dp(6), 0)
        }
        statusDot = dot

        // Acilir menu (baslangicta gizli)
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        fun closeMenu() { menu.visibility = View.GONE }
        menu.addView(section("Kalibrasyon"))
        menu.addView(row(
            btn("Portal alanı", 96) { closeMenu(); startCalib(0) },
            btn("Çizgi alanı", 96) { closeMenu(); startCalib(4) }
        ))
        menu.addView(row(
            btn("Harita tuşu", 96) { closeMenu(); startCalib(3) },
            btn("Atlama tuşu", 96) { closeMenu(); startCalib(1) }
        ))
        menu.addView(row(
            btn("Rota", 96) { closeMenu(); startCalib(2) }
        ))
        menu.addView(section("Araçlar"))
        menu.addView(row(
            btn("Test", 96) { runTest() },
            btn("Kapat", 96) { stopSelf() }
        ))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(handle)
            addView(dot)
            addView(btn("Başlat", 56) { startBot() })
            addView(btn("Durdur", 56) { running = false; toast("Durduruldu") })
            addView(btn("Menü", 48) {
                menu.visibility = if (menu.visibility == View.GONE) View.VISIBLE else View.GONE
            })
        }
        root.addView(top)
        root.addView(menu)
        panel = root
        wm.addView(root, lp)
    }

    private fun startCalib(mode: Int) {
        running = false
        panel?.visibility = View.GONE
        val v = CalibView(this, cfg, mode) {
            ui.post {
                calib?.let { try { wm.removeView(it) } catch (_: Exception) {} }
                calib = null
                panel?.visibility = View.VISIBLE
            }
        }
        calib = v
        wm.addView(v, WindowManager.LayoutParams(
            MP, MP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ))
    }

    private fun runTest() {
        Thread {
            if (cfg.rect("zone") == null) { toast("Once Bolge ciz"); return@Thread }
            val s = scanNow()
            val minPx = cfg.f("minPx", 40f).toInt()
            if (s == null) { toast("Ekran alinamadi"); return@Thread }
            val ok = s.n >= minPx
            if (ok) mark(s.x, s.y, Color.MAGENTA, 2500)
            val yel = if (cfg.rect("mini") != null) " | Sari: ${yellowCount()} (esik ${cfg.f("yPx", 15f).toInt()})" else ""
            toast("Halka benzeri: ${s.n}px, toplam mavi: ${s.raw} (esik $minPx) -> " + (if (ok) "PORTAL VAR @ ${s.x},${s.y}" else "portal yok") + yel)
        }.start()
    }

    private fun startBot() {
        if (running) return
        running = true
        Thread {
            if (cfg.rect("zone") != null) {
                val s = scanNow()
                val minPx = cfg.f("minPx", 40f).toInt()
                if (s != null && s.n >= minPx) {
                    toast("Bolgede su an ${s.n}px mavi var (esik $minPx). Portal yokken baslat ya da esigi yukselt.")
                    running = false
                    return@Thread
                }
            }
            toast("Basladi")
            runLoop()
        }.start()
    }

    // ---------- Ekran yakalama ----------
    @Suppress("DEPRECATION")
    private fun ensureDisplay(): Boolean {
        val proj = projection ?: return false
        val dm = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        if (vd != null && w == curW && h == curH) return true
        reader?.close()
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val existing = vd
        if (existing == null) {
            vd = proj.createVirtualDisplay(
                "cap", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
        } else {
            existing.resize(w, h, dm.densityDpi)
            existing.surface = r.surface
        }
        reader = r
        curW = w
        curH = h
        lastBmp?.recycle()
        lastBmp = null
        return true
    }

    private fun grab(): Bitmap? {
        if (!ensureDisplay()) return null
        var tries = 0
        while (tries < 15) {
            val img = reader?.acquireLatestImage()
            if (img != null) {
                try {
                    val pl = img.planes[0]
                    val pw = pl.rowStride / pl.pixelStride
                    val bmp = Bitmap.createBitmap(pw, img.height, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(pl.buffer)
                    lastBmp?.recycle()
                    lastBmp = bmp
                } finally {
                    img.close()
                }
                return lastBmp
            }
            if (lastBmp != null) return lastBmp
            Thread.sleep(100)
            tries++
        }
        return lastBmp
    }

    @Synchronized
    private fun scanNow(): Hit? {
        val zone = cfg.rect("zone") ?: return null
        val bmp = grab() ?: return null
        return Detector.scan(bmp, zone, cfg)
    }

    @Synchronized
    private fun detect(): Hit? {
        val zone = cfg.rect("zone") ?: return null
        val bmp = grab() ?: return null
        return Detector.find(bmp, zone, cfg)
    }

    // ---------- Bot dongusu ----------
    private fun pause(ms: Long) {
        var t = 0L
        while (running && t < ms) { Thread.sleep(100); t += 100 }
    }

    private fun tap(x: Int, y: Int) {
        val dMin = cfg.f("dMin", 200f).toInt()
        val dMax = cfg.f("dMax", 800f).toInt()
        if (dMax > 0) pause(if (dMax > dMin) (dMin..dMax).random().toLong() else dMax.toLong())
        if (!running) return
        val s = TapService.instance
        if (s == null) { toast("Erisilebilirlik servisi kapali"); running = false; return }
        val tx = x + (-3..3).random()
        val ty = y + (-3..3).random()
        mark(tx, ty, Color.RED, 700)
        if (!s.tapBlocking(tx, ty)) {
            pause(150)
            if (running) s.tapBlocking(tx, ty)
        }
    }

    private fun waitForPortal(sec: Float): Hit? {
        var t = 0L
        while (running && t < (sec * 1000).toLong()) {
            pause(500)
            t += 500
            if (System.currentTimeMillis() > ignoreUntil) {
                val h = detect()
                if (h != null) return h
            }
        }
        return null
    }

    @Synchronized
    private fun yellowCount(): Int {
        val r = cfg.rect("mini") ?: return 0
        val bmp = grab() ?: return 0
        return Detector.countYellow(bmp, r, cfg)
    }

    /** Sari yol cizgisi kaybolana kadar bekler. pollPortal=true ise bu sirada portal da arar. */
    private fun waitLineGone(pollPortal: Boolean): Hit? {
        if (cfg.rect("mini") == null) return null
        val minY = cfg.f("yPx", 15f).toInt()
        val maxMs = (cfg.f("yWait", 25f) * 1000).toLong()
        val t0 = System.currentTimeMillis()
        var seen = false
        var gone = 0
        while (running) {
            val el = System.currentTimeMillis() - t0
            if (el > maxMs) { toast("Sari cizgi ${maxMs / 1000} sn icinde kaybolmadi, devam ediyorum"); break }
            pause(250)
            if (yellowCount() >= minY) {
                seen = true
                gone = 0
            } else {
                gone++
                if (seen && gone >= 2) break
                if (!seen && el > 1500) break
            }
            if (pollPortal && System.currentTimeMillis() > ignoreUntil) {
                val h = detect()
                if (h != null) return h
            }
        }
        return null
    }

    private fun confirm(h: Hit): Hit? {
        var cur = h
        repeat(3) {
            pause(400)
            if (!running) return null
            val n = detect() ?: return null
            if (kotlin.math.abs(n.x - h.x) > 12 || kotlin.math.abs(n.y - h.y) > 12) return null
            cur = n
        }
        return cur
    }

    private fun runLoop() {
        try {
            loopBody()
        } catch (e: Throwable) {
            toast("Hata: ${e.javaClass.simpleName} ${e.message}")
        } finally {
            running = false
            toast("Dongu durdu")
        }
    }

    private fun loopBody() {
        val wps = cfg.waypoints()
        val jump = cfg.point("jump")
        val mapBtn = cfg.point("mapbtn")
        if (cfg.rect("zone") == null || jump == null || wps.isEmpty()) {
            toast("Once Bolge, Atla ve Rota kalibre et")
            return
        }
        val start = System.currentTimeMillis()
        val maxMs = (cfg.f("maxMin", 60f) * 60_000f).toLong()
        var idx = 0
        var fails = 0
        var pending: Hit? = null
        while (running) {
            if (System.currentTimeMillis() - start > maxMs) { toast("Sure doldu, durdu"); break }
            val cand = pending ?: (if (System.currentTimeMillis() > ignoreUntil) detect() else null)
            pending = null
            val h = if (cand != null) confirm(cand) else null
            if (h != null) {
                toast("Portal bulundu (${h.n}px) @ ${h.x},${h.y}")
                mark(h.x, h.y, Color.MAGENTA, 1500)
                // 1) haritada portala git
                tap(h.x, h.y)
                if (cfg.rect("mini") != null) waitLineGone(false) else pause((cfg.f("travel", 6f) * 1000).toLong())
                // 2) haritayi kapat
                if (mapBtn != null) { tap(mapBtn.x, mapBtn.y); pause(1000) }
                // 3) atlama butonuna 2 kez, 1 sn arayla
                tap(jump.x, jump.y)
                pause(1000)
                tap(jump.x, jump.y)
                pause(1500)
                // 4) haritayi tekrar ac
                if (mapBtn != null) { tap(mapBtn.x, mapBtn.y); pause(1500) }
                if (running && detect() != null) {
                    fails++
                    if (fails >= 3) { ignoreUntil = System.currentTimeMillis() + 30_000; fails = 0 }
                } else {
                    fails = 0
                }
                continue
            }
            // portal yok: rotadaki siradaki noktaya git, tum liste bitince basa don
            val p = wps[idx]
            idx = (idx + 1) % wps.size
            tap(p.x, p.y)
            pending = waitLineGone(true)
            if (pending == null && running) pending = waitForPortal(cfg.f("wait", 0f))
        }
    }

    override fun onDestroy() {
        if (stopping) return
        stopping = true
        running = false
        if (::wm.isInitialized) {
            panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            calib?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        }
        vd?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
