package com.example.maproute

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class BotService : Service() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var cfg: Cfg
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var curW = 0
    private var curH = 0
    private var lastBmp: Bitmap? = null

    private var panel: View? = null
    private var calib: View? = null
    private var dialog: View? = null
    private var marker: MarkerView? = null
    private var stats: TextView? = null
    private var statsLp: WindowManager.LayoutParams? = null
    private var statsPos = 0
    private var statusDot: TextView? = null
    private var pauseBtn: Button? = null
    private var stopping = false

    // ---- calisma durumu ----
    @Volatile private var running = false
        set(v) {
            field = v
            refreshStatus()
        }
    @Volatile private var paused = false
    @Volatile private var pauseStart = 0L
    @Volatile private var pausedAccum = 0L
    @Volatile private var ignoreUntil = 0L
    @Volatile private var lastLineSeen = false

    // ---- istatistik / mod ----
    @Volatile private var runStartMs = 0L
    @Volatile private var runEndMs = 0L
    @Volatile private var jumpCount = 0
    @Volatile private var yJumps = 0
    @Volatile private var standN = 0          // basta sorulan sayi: bu kadar portal atlanana kadar rotaya cikma
    @Volatile private var standManual = false // sari portal sonrasi vb.: "Rotaya gec"e kadar bekle

    private fun standing(): Boolean = standManual || jumpCount < standN

    private fun fmt(sec: Long): String =
        String.format("%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)

    private fun refreshStatus() {
        ui.post {
            val c = if (!running) 0xFFFF5252.toInt() else if (paused) 0xFFFFC107.toInt() else 0xFF4CAF50.toInt()
            statusDot?.setTextColor(c)
            pauseBtn?.text = if (paused) "Devam" else "Beklet"
        }
    }

    @Synchronized
    private fun setPaused(v: Boolean) {
        if (v == paused) return
        val now = System.currentTimeMillis()
        if (v) pauseStart = now else pausedAccum += now - pauseStart
        paused = v
        refreshStatus()
    }

    private fun togglePause() {
        if (!running) { toast("Bot calismiyor"); return }
        setPaused(!paused)
        toast(if (paused) "Beklemede (hicbir sey sifirlanmadi)" else "Devam ediyor")
    }

    private fun leaveStanding() {
        standManual = false
        standN = 0
        toast("Rotaya gecildi")
    }

    private val statsTick: Runnable = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            val end = if (running) now else (if (runEndMs > 0) runEndMs else runStartMs)
            val curPause = if (paused && pauseStart > 0) now - pauseStart else 0L
            val el = if (runStartMs > 0) ((end - runStartMs - pausedAccum - curPause) / 1000).coerceAtLeast(0) else 0L
            val avg = if (jumpCount > 0) fmt(el / jumpCount) + " / portal" else "-"
            val mode = when {
                !running -> "Durdu"
                paused -> "Beklet"
                standManual -> "Bekleme modu"
                jumpCount < standN -> "Bekleme ($jumpCount/$standN)"
                else -> "Rota"
            }
            val ys = if (yJumps > 0) " (sarı: $yJumps)" else ""
            stats?.text = "Mod: $mode\nSüre: ${fmt(el)}\nAtlanan portal: $jumpCount$ys\nOrtalama: $avg"
            ui.postDelayed(this, 1000)
        }
    }

    private fun cycleStats() {
        val st = stats ?: return
        val lp = statsLp ?: return
        statsPos = (statsPos + 1) % 5
        if (statsPos == 4) { st.visibility = View.GONE; return }
        st.visibility = View.VISIBLE
        lp.gravity = when (statsPos) {
            0 -> Gravity.BOTTOM or Gravity.START
            1 -> Gravity.BOTTOM or Gravity.END
            2 -> Gravity.TOP or Gravity.END
            else -> Gravity.TOP or Gravity.START
        }
        wm.updateViewLayout(st, lp)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null || intent == null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        cfg = Cfg(this)
        startFg()
        val code = intent.getIntExtra("code", 0)
        val data = readData(intent)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { running = false; ui.post { stopSelf() } }
        }, ui)
        showPanel()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra<Intent>("data")

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "MapRoute", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bot")
            .setContentTitle("MapRoute calisiyor")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun toast(s: String) { ui.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() } }

    // ---------- Panel ----------
    private fun mark(x: Int, y: Int, color: Int, dur: Long) {
        if (cfg.f("dbg", 1f) < 0.5f) return
        ui.post { marker?.add(x, y, color, dur) }
    }

    private fun showPanel() {
        val mv = MarkerView(this)
        marker = mv
        wm.addView(mv, WindowManager.LayoutParams(
            MP, MP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ))

        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD1E1E1E.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val lp = WindowManager.LayoutParams(
            WC, WC, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }

        fun btn(t: String, minW: Int, a: () -> Unit): Button = Button(this).apply {
            text = t
            textSize = 12f
            isAllCaps = false
            minWidth = 0
            minimumWidth = dp(minW)
            minHeight = 0
            minimumHeight = dp(36)
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { a() }
        }
        fun section(t: String) = TextView(this).apply {
            text = t
            textSize = 11f
            setTextColor(0xFFAAAAAA.toInt())
            setPadding(dp(4), dp(6), 0, dp(2))
        }
        fun row(vararg b: Button) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            for (x in b) addView(x)
        }

        var dx = 0f
        var dy = 0f
        val handle = TextView(this).apply {
            text = "::"
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(8), 0, dp(10), 0)
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = lp.x - e.rawX; dy = lp.y - e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = (e.rawX + dx).toInt(); lp.y = (e.rawY + dy).toInt()
                        wm.updateViewLayout(root, lp)
                    }
                }
                true
            }
        }
        val dot = TextView(this).apply {
            text = "●"
            textSize = 16f
            setTextColor(0xFFFF5252.toInt())
            setPadding(0, 0, dp(6), 0)
        }
        statusDot = dot

        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        fun closeMenu() { menu.visibility = View.GONE }
        menu.addView(section("Kalibrasyon"))
        menu.addView(row(
            btn("Portal alanı", 104) { closeMenu(); startCalib(0) },
            btn("Sarı portal alanı", 104) { closeMenu(); startCalib(5) }
        ))
        menu.addView(row(
            btn("Çizgi alanı", 104) { closeMenu(); startCalib(4) },
            btn("Harita tuşu", 104) { closeMenu(); startCalib(3) }
        ))
        menu.addView(row(
            btn("Atlama tuşu", 104) { closeMenu(); startCalib(1) },
            btn("Rota", 104) { closeMenu(); startCalib(2) }
        ))
        menu.addView(section("Araçlar"))
        menu.addView(row(
            btn("Test", 104) { runTest() },
            btn("İstatistik", 104) { cycleStats() }
        ))
        menu.addView(row(
            btn("Rotaya geç", 104) { closeMenu(); leaveStanding() },
            btn("Kapat", 104) { stopSelf() }
        ))

        val pb = btn("Beklet", 56) { togglePause() }
        pauseBtn = pb
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(handle)
            addView(dot)
            addView(btn("Başlat", 56) { closeMenu(); askStartCount() })
            addView(pb)
            addView(btn("Durdur", 56) {
                if (running) { running = false; toast("Durduruldu (sayaçlar sıfırlanır)") }
            })
            addView(btn("Menü", 48) {
                menu.visibility = if (menu.visibility == View.GONE) View.VISIBLE else View.GONE
            })
        }
        root.addView(top)
        root.addView(menu)
        panel = root
        wm.addView(root, lp)

        val st = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        stats = st
        val slp = WindowManager.LayoutParams(
            WC, WC, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START }
        statsLp = slp
        wm.addView(st, slp)
        ui.post(statsTick)
    }

    // ---------- Baslat: "kac portal atlanana kadar bekle" sorusu ----------
    private fun closeDialog() {
        dialog?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        dialog = null
    }

    private fun askStartCount() {
        if (running) { toast("Zaten calisiyor (Beklet / Durdur kullan)"); return }
        if (dialog != null) return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        var n = cfg.f("startN", 0f).toInt().coerceIn(0, 99)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEE222222.toInt())
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        box.addView(TextView(this).apply {
            text = "Rotaya geçmeden önce kaç portal atlansın?\n(0 = hemen rota)"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
        })
        val num = TextView(this).apply {
            text = "$n"
            textSize = 32f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
        }
        box.addView(num)
        fun step(label: String, delta: Int): Button = Button(this).apply {
            text = label
            isAllCaps = false
            minWidth = 0
            minimumWidth = dp(56)
            setOnClickListener { n = (n + delta).coerceIn(0, 99); num.text = "$n" }
        }
        box.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(step("-5", -5))
            addView(step("-1", -1))
            addView(step("+1", 1))
            addView(step("+5", 5))
        })
        box.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(Button(this@BotService).apply {
                text = "Başlat"
                isAllCaps = false
                setOnClickListener {
                    cfg.put("startN", n.toFloat())
                    closeDialog()
                    standN = n
                    startBot()
                }
            })
            addView(Button(this@BotService).apply {
                text = "İptal"
                isAllCaps = false
                setOnClickListener { closeDialog() }
            })
        })
        dialog = box
        wm.addView(box, WindowManager.LayoutParams(
            WC, WC, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER })
    }

    private fun startCalib(mode: Int) {
        running = false
        panel?.visibility = View.GONE
        val v = CalibView(this, cfg, mode) {
            ui.post {
                calib?.let { try { wm.removeView(it) } catch (_: Exception) {} }
                calib = null
                panel?.visibility = View.VISIBLE
            }
        }
        calib = v
        wm.addView(v, WindowManager.LayoutParams(
            MP, MP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ))
    }

    private fun runTest() {
        Thread {
            if (cfg.rect("zone") == null) { toast("Once Portal alani ciz"); return@Thread }
            val s = scanNow()
            val minPx = cfg.f("minPx", 40f).toInt()
            if (s == null) { toast("Ekran alinamadi"); return@Thread }
            val ok = s.n >= minPx
            if (ok) mark(s.x, s.y, Color.MAGENTA, 2500)
            val yel = if (cfg.rect("mini") != null) " | Sari cizgi: ${yellowCount()} (esik ${cfg.f("yPx", 15f).toInt()})" else ""
            var yp = ""
            val ys = scanYellowNow()
            if (ys != null) {
                val pyPx = cfg.f("pyPx", 40f).toInt()
                val yok = ys.n >= pyPx
                if (yok) mark(ys.x, ys.y, Color.MAGENTA, 2500)
                yp = " | SARI PORTAL: ${ys.n}px, toplam sari: ${ys.raw} (esik $pyPx) -> " + (if (yok) "VAR @ ${ys.x},${ys.y}" else "yok")
            }
            toast("Mavi portal: ${s.n}px, toplam mavi: ${s.raw} (esik $minPx) -> " + (if (ok) "VAR @ ${s.x},${s.y}" else "yok") + yel + yp)
        }.start()
    }

    private fun startBot() {
        if (running) return
        running = true
        Thread {
            if (cfg.rect("zone") != null) {
                val s = scanNow()
                val minPx = cfg.f("minPx", 40f).toInt()
                if (s != null && s.n >= minPx) {
                    if (standN > 0) {
                        toast("Bolgede portal gorunuyor, hemen gidecek")
                    } else {
                        toast("Bolgede su an ${s.n}px mavi var (esik $minPx). Portal yokken baslat ya da esigi yukselt.")
                        running = false
                        return@Thread
                    }
                }
            }
            toast("Basladi")
            jumpCount = 0
            yJumps = 0
            standManual = false
            paused = false
            pauseStart = 0L
            pausedAccum = 0L
            runEndMs = 0L
            runStartMs = System.currentTimeMillis()
            runLoop()
        }.start()
    }

    // ---------- Ekran yakalama ----------
    @Suppress("DEPRECATION")
    private fun ensureDisplay(): Boolean {
        val proj = projection ?: return false
        val dm = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        if (vd != null && w == curW && h == curH) return true
        reader?.close()
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val existing = vd
        if (existing == null) {
            vd = proj.createVirtualDisplay(
                "cap", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
        } else {
            existing.resize(w, h, dm.densityDpi)
            existing.surface = r.surface
        }
        reader = r
        curW = w
        curH = h
        lastBmp?.recycle()
        lastBmp = null
        return true
    }

    private fun grab(): Bitmap? {
        if (!ensureDisplay()) return null
        var tries = 0
        while (tries < 15) {
            val img = reader?.acquireLatestImage()
            if (img != null) {
                try {
                    val pl = img.planes[0]
                    val pw = pl.rowStride / pl.pixelStride
                    val bmp = Bitmap.createBitmap(pw, img.height, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(pl.buffer)
                    lastBmp?.recycle()
                    lastBmp = bmp
                } finally {
                    img.close()
                }
                return lastBmp
            }
            if (lastBmp != null) return lastBmp
            Thread.sleep(100)
            tries++
        }
        return lastBmp
    }

    @Synchronized
    private fun scanNow(): Hit? {
        val zone = cfg.rect("zone") ?: return null
        val bmp = grab() ?: return null
        return Detector.scan(bmp, zone, cfg)
    }

    @Synchronized
    private fun scanYellowNow(): Hit? {
        val zone = cfg.rect("yzone") ?: return null
        val bmp = grab() ?: return null
        return Detector.scanYellow(bmp, zone, cfg)
    }

    /** Mavi portal alani, sonra (varsa) sari portal alani. kind: 0 mavi, 1 sari. */
    @Synchronized
    private fun detect(): Hit? {
        val bmp = grab() ?: return null
        val z = cfg.rect("zone")
        if (z != null) {
            val h = Detector.find(bmp, z, cfg)
            if (h != null) return h
        }
        val yz = cfg.rect("yzone")
        if (yz != null) {
            val h = Detector.findYellow(bmp, yz, cfg)
            if (h != null) return h.copy(kind = 1)
        }
        return null
    }

    @Synchronized
    private fun yellowCount(): Int {
        val r = cfg.rect("mini") ?: return 0
        val bmp = grab() ?: return 0
        // sari portalin kendi halkasi "yol cizgisi" sayilmasin
        return Detector.countYellow(bmp, r, cfg, cfg.rect("yzone"))
    }

    // ---------- Bot dongusu ----------
    /** ms kadar bekler; Beklet'teyken sure islemez (devam edince kaldigi yerden). */
    private fun pause(ms: Long) {
        var t = 0L
        while (running && t < ms) {
            Thread.sleep(100)
            if (!paused) t += 100
        }
    }

    private fun waitIfPaused() {
        while (running && paused) Thread.sleep(100)
    }

    private fun tap(x: Int, y: Int) {
        waitIfPaused()
        val dMin = cfg.f("dMin", 200f).toInt()
        val dMax = cfg.f("dMax", 800f).toInt()
        if (dMax > 0) pause(if (dMax > dMin) (dMin..dMax).random().toLong() else dMax.toLong())
        if (!running) return
        val s = TapService.instance
        if (s == null) { toast("Erisilebilirlik servisi kapali"); running = false; return }
        val tx = x + (-3..3).random()
        val ty = y + (-3..3).random()
        mark(tx, ty, Color.RED, 700)
        if (!s.tapBlocking(tx, ty)) {
            pause(150)
            if (running) s.tapBlocking(tx, ty)
        }
    }

    private fun waitForPortal(sec: Float): Hit? {
        var t = 0L
        while (running && t < (sec * 1000).toLong()) {
            pause(500)
            t += 500
            if (System.currentTimeMillis() > ignoreUntil) {
                val h = detect()
                if (h != null) return h
            }
        }
        return null
    }

    /** Sari yol cizgisi kaybolana kadar bekler. pollPortal=true ise bu sirada portal da arar. */
    private fun waitLineGone(pollPortal: Boolean): Hit? {
        lastLineSeen = false
        if (cfg.rect("mini") == null) return null
        val minY = cfg.f("yPx", 15f).toInt()
        val maxMs = (cfg.f("yWait", 45f) * 1000).toLong()
        val t0 = System.currentTimeMillis()
        var seen = false
        var gone = 0
        while (running) {
            val el = System.currentTimeMillis() - t0 - pausedAccum
            if (el > maxMs) { toast("Sari cizgi ${maxMs / 1000} sn icinde kaybolmadi, devam ediyorum"); break }
            pause(250)
            if (yellowCount() >= minY) {
                seen = true
                lastLineSeen = true
                gone = 0
            } else {
                gone++
                if (seen && gone >= 2) break
                if (!seen && el > 1500) break
            }
            if (pollPortal && System.currentTimeMillis() > ignoreUntil) {
                val h = detect()
                if (h != null) return h
            }
        }
        return null
    }

    /**
     * a noktasindan b noktasina verilen hizla surukler. Surukleme KISA parcalara (~1,5 sn) bolunur;
     * boylece portal gorulunce parmak hemen kalkmis olur ve portala dokunus yarida kalan bir
     * surukleme yuzunden iptal olmaz. Surerken portal gorurse Hit doner.
     */
    private fun dragSegment(a: Point, b: Point, speed: Float): Hit? {
        val s = TapService.instance
        if (s == null) { toast("Erisilebilirlik servisi kapali"); running = false; return null }
        val dist = kotlin.math.hypot((b.x - a.x).toDouble(), (b.y - a.y).toDouble())
        val totalMs = (dist / speed * 1000.0).coerceAtLeast(300.0)
        val parts = kotlin.math.ceil(totalMs / 1500.0).toInt().coerceAtLeast(1)
        var px = a.x
        var py = a.y
        for (i in 1..parts) {
            val nx = a.x + (b.x - a.x) * i / parts
            val ny = a.y + (b.y - a.y) * i / parts
            val h = dragPart(s, px, py, nx, ny, (totalMs / parts).toLong())
            if (h != null) return h
            if (!running) return null
            px = nx
            py = ny
        }
        return null
    }

    private fun dragPart(s: TapService, x1: Int, y1: Int, x2: Int, y2: Int, ms: Long): Hit? {
        var tries = 0
        while (running && tries < 3) {
            tries++
            waitIfPaused()
            if (!running) return null
            val latch = java.util.concurrent.CountDownLatch(1)
            var ok = false
            mark(x2, y2, Color.RED, ms.coerceAtMost(2000L))
            val sent = s.dragAsync(x1, y1, x2, y2, ms) { r -> ok = r; latch.countDown() }
            if (!sent) { pause(200); continue }
            var found: Hit? = null
            while (running) {
                if (latch.await(250, java.util.concurrent.TimeUnit.MILLISECONDS)) break
                if (found == null && System.currentTimeMillis() > ignoreUntil) found = detect()
            }
            if (found != null) return found   // parca bitti, parmak kalkti
            if (ok || !running) return null
            pause(150)
        }
        return null
    }

    private fun confirm(h: Hit): Hit? {
        var cur = h
        repeat(3) {
            pause(400)
            if (!running) return null
            val n = detect() ?: return null
            if (n.kind != h.kind || kotlin.math.abs(n.x - h.x) > 12 || kotlin.math.abs(n.y - h.y) > 12) return null
            cur = n
        }
        return cur
    }

    private fun afterYellow() {
        when (cfg.f("yAfter", 1f).toInt()) {
            1 -> { toast("Sari portal atlandi: beklemede (Devam'a bas)"); setPaused(true) }
            2 -> { standManual = true; toast("Sari portal atlandi: bekleme modu (Rotaya gec ile cik)") }
            else -> toast("Sari portal atlandi")
        }
    }

    private fun runLoop() {
        try {
            loopBody()
        } catch (e: Throwable) {
            toast("Hata: ${e.javaClass.simpleName} ${e.message}")
        } finally {
            setPaused(false)
            running = false
            runEndMs = System.currentTimeMillis()
            toast("Dongu durdu")
        }
    }

    private fun loopBody() {
        val wps = cfg.waypoints()
        val jump = cfg.point("jump")
        val mapBtn = cfg.point("mapbtn")
        if (cfg.rect("zone") == null || jump == null || wps.isEmpty()) {
            toast("Once Portal alani, Atlama tusu ve Rota kalibre et")
            return
        }
        val start = System.currentTimeMillis()
        val maxMs = (cfg.f("maxMin", 60f) * 60_000f).toLong()
        var idx = 0
        var fails = 0
        var pending: Hit? = null
        while (running) {
            waitIfPaused()
            if (!running) break
            if (System.currentTimeMillis() - start - pausedAccum > maxMs) { toast("Sure doldu, durdu"); break }
            val cand = pending ?: (if (System.currentTimeMillis() > ignoreUntil) detect() else null)
            pending = null
            val h = if (cand != null) confirm(cand) else null
            if (h != null) {
                val yellow = h.kind == 1
                toast((if (yellow) "SARI portal bulundu" else "Portal bulundu") + " (${h.n}px) @ ${h.x},${h.y}")
                mark(h.x, h.y, Color.MAGENTA, 1500)
                // 1) haritada portalin ortasina git (dokunus kayit olmadiysa bir kez daha dene)
                var att = 0
                do {
                    tap(h.x, h.y)
                    att++
                    if (cfg.rect("mini") != null) waitLineGone(false) else pause((cfg.f("travel", 6f) * 1000).toLong())
                } while (running && cfg.rect("mini") != null && !lastLineSeen && att < 2)
                pause((cfg.f("arrive", 1.5f) * 1000).toLong())
                // 2) haritayi kapat
                if (mapBtn != null) { tap(mapBtn.x, mapBtn.y); pause(1000) }
                // 3) atlama butonuna 2 kez, 1 sn arayla
                tap(jump.x, jump.y)
                pause(1000)
                tap(jump.x, jump.y)
                pause(1500)
                // 4) haritayi tekrar ac
                if (mapBtn != null) { tap(mapBtn.x, mapBtn.y); pause(1500) }
                if (running && detect() != null) {
                    fails++
                    if (fails >= 3) { ignoreUntil = System.currentTimeMillis() + 30_000; fails = 0 }
                } else {
                    fails = 0
                    if (running) {
                        jumpCount++
                        if (yellow) {
                            yJumps++
                            afterYellow()
                        } else {
                            toast("Portal atlandi (toplam $jumpCount)")
                        }
                    }
                }
                continue
            }
            // Bekleme modu: rotada ilerleme, sadece portal bekle
            if (standing()) { pause(300); continue }

            // Rota
            if (cfg.f("dragMode", 1f) >= 0.5f) {
                val a = wps[idx]
                val b = wps[(idx + 1) % wps.size]
                pending = dragSegment(a, b, cfg.f("dragSpeed", 20f).coerceAtLeast(1f))
                if (pending == null && running) idx = (idx + 1) % wps.size
            } else {
                val p = wps[idx]
                idx = (idx + 1) % wps.size
                tap(p.x, p.y)
                pending = waitLineGone(true)
                if (pending == null && running) pending = waitForPortal(cfg.f("wait", 0f))
            }
        }
    }

    override fun onDestroy() {
        if (stopping) return
        stopping = true
        running = false
        if (::wm.isInitialized) {
            panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            calib?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            dialog?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            marker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            stats?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            ui.removeCallbacks(statsTick)
        }
        vd?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
