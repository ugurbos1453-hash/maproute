package com.example.maproute

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private val fields = LinkedHashMap<String, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 120, 40, 60)
        }
        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)

        fun label(t: String) {
            col.addView(TextView(this).apply { text = t; setPadding(0, 14, 0, 6) })
        }
        fun button(t: String, a: () -> Unit) {
            col.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { a() } })
        }

        label("MapRoute\n\n1) Ekran ustu izni ver.\n" +
            "2) Uygulama bilgisi > sag ust menu > 'Kisitli ayarlara izin ver' (Android 16 / HyperOS).\n" +
            "3) Erisilebilirlik > MapRoute Dokunma > ac.\n" +
            "4) Uygulama bilgisi: Otomatik baslat ac, pil kisitlamasi 'Kisitlama yok'.\n" +
            "5) Baslat'a bas, ekran paylasiminda 'Tum ekran' sec. Panel acilir; oyuna gec.\n" +
            "6) Panelde Menu > Portal alani / Cizgi alani / Harita tusu / Atlama tusu / Rota kalibre et, Test ile dene, sonra Baslat.")

        button("Ekran ustu izni ver") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("Uygulama bilgisi (kisitli ayarlar, pil)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        button("Erisilebilirlik ayarlari") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        label("Ayarlar")
        val defs = listOf(
            Triple("hMin", "Renk tonu min (0-360)", 180f),
            Triple("hMax", "Renk tonu max (0-360)", 220f),
            Triple("sMin", "Doygunluk min (0-1)", 0.45f),
            Triple("vMin", "Parlaklik min (0-1)", 0.5f),
            Triple("minPx", "Portal icin min piksel sayisi", 40f),
            Triple("maxFill", "Sekil: maks doluluk (0-1, halka icin 0.6)", 0.6f),
            Triple("dbg", "Dokunma/portal isaretlerini goster (1/0)", 1f),
            Triple("dragMode", "Rota modu: 1 = sürükle, 0 = tıkla", 1f),
            Triple("dragSpeed", "Sürükleme hızı (piksel/sn)", 20f),
            Triple("wait", "Varışta ek bekleme (sn) - 0 = beklemeden devam", 0f),
            Triple("dMin", "Dokunma öncesi gecikme min (ms)", 200f),
            Triple("dMax", "Dokunma öncesi gecikme max (ms) - 0 = gecikmesiz", 800f),
            Triple("travel", "Portala varis suresi (sn, cizgi alani yoksa)", 6f),
            Triple("yMin", "Sari cizgi ton min (0-360)", 30f),
            Triple("yMax", "Sari cizgi ton max (0-360)", 50f),
            Triple("ySat", "Sari cizgi doygunluk min (0-1)", 0.45f),
            Triple("yVal", "Sari cizgi parlaklik min (0-1)", 0.5f),
            Triple("yPx", "Sari cizgi icin min piksel", 15f),
            Triple("yWait", "Cizgi kaybolma bekleme siniri (sn) - uzak portal icin artir", 45f),
            Triple("arrive", "Portala varinca ek bekleme (sn) - atlamadan once", 1.5f),
            Triple("pyMin", "Sarı portal ton min (0-360)", 30f),
            Triple("pyMax", "Sarı portal ton max (0-360)", 50f),
            Triple("pySat", "Sarı portal doygunluk min (0-1)", 0.45f),
            Triple("pyVal", "Sarı portal parlaklık min (0-1)", 0.5f),
            Triple("pyPx", "Sarı portal için min piksel", 40f),
            Triple("pyHollow", "Sarı portal ortası boş olsun (1/0)", 1f),
            Triple("yAfter", "Sarı portaldan sonra: 1 = beklet, 2 = bekleme modu, 0 = devam", 1f),
            Triple("maxMin", "Otomatik durma (dakika)", 60f)
        )
        for ((k, name, d) in defs) {
            label(name)
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setText(cfg.f(k, d).toString())
            }
            fields[k] = e
            col.addView(e)
        }
        button("Ayarlari kaydet") { saveFields(); Toast.makeText(this, "Kaydedildi", Toast.LENGTH_SHORT).show() }
        button("BASLAT (paneli ac)") {
            saveFields()
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Once ekran ustu izni ver", Toast.LENGTH_LONG).show()
            } else {
                val mpm = getSystemService(MediaProjectionManager::class.java)
                @Suppress("DEPRECATION")
                startActivityForResult(mpm.createScreenCaptureIntent(), 100)
            }
        }
    }

    private fun saveFields() {
        for ((k, e) in fields) e.text.toString().toFloatOrNull()?.let { cfg.put(k, it) }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, BotService::class.java).putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Panel acildi, oyuna gec", Toast.LENGTH_LONG).show()
        }
    }
}
